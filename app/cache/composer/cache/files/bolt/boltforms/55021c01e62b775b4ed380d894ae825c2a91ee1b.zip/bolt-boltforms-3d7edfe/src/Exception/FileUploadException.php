<?php
namespace Bolt\Extension\Bolt\BoltForms\Exception;

class FileUploadException extends \Exception
{
}
