<?php
namespace Bolt\Extension\Bolt\BoltForms\Exception;

class EmailException extends \Exception
{
}
