<?php
namespace Bolt\Extension\Bolt\BoltForms\Exception;

class FormValidationException extends \Exception
{
}
